
var gameTypeUrls = {
  "hand_eye": "https://google.com",
  "Decision Making": "https://example.com/decision-making"
};

function selectGameType() {
  var gameType = document.getElementById("game-type").value;
  var gameTypeUrl = gameTypeUrls[gameType];
  window.location.href = gameTypeUrl;
}


document.getElementById("Hand-Eye").onclick = function () {
    window.location.href = "www.google.com";
};

function required() {
  var empt = document.getElementById("pname").value;
  if(empt === "") {
    alert("Please enter player name.");
    return false;
  }
  else return true;
}